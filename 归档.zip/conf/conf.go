package conf

// var DSN = "bysystem:P5wsasJiptNaGmYh@tcp(43.248.100.60:3306)/select_job?charset=utf8mb4&parseTime=True&loc=Local"
//var DSNL = "root:abc123456@tcp(localhost:3306)/job?charset=utf8mb4&parseTime=True&loc=Local"

var DSNL = "byth_job:SyBk4pwNCM6sprTB@tcp(101.35.245.54:3306)/byth_job?charset=utf8mb4&parseTime=True&loc=Local"
